package com.event.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.event.bean.AddEventBean;

/**
 * Servlet implementation class AddEvent
 */
@WebServlet("/AddEvent")
public class AddEvent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		AddEventBean objAddEventBean = new AddEventBean();
		objAddEventBean.setEvent_name(request.getParameter("eventname"));
		objAddEventBean.setEvent_name(request.getParameter("startdate"));
		objAddEventBean.setEvent_name(request.getParameter("enddate"));
		objAddEventBean.setEvent_name(request.getParameter("venue"));
		objAddEventBean.setEvent_name(request.getParameter("time"));
		objAddEventBean.setEvent_name(request.getParameter("expectamount"));
	}

}
