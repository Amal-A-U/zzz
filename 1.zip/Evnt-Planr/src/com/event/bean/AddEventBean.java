package com.event.bean;

public class AddEventBean {
	private  String event_id;
	private  String event_name;
	private  String start_date;
	private  String end_date;
	private  String venue;
	private  String time;
	private  String expected_amount;
	private  String total_amount;
	private  String event_status;
	/**
	 * @return the event_id
	 */
	/**
	 * @return the event_id
	 */
	public String getEvent_id() {
		return event_id;
	}
	/**
	 * @param event_id the event_id to set
	 */
	public void setEvent_id(String event_id) {
		this.event_id = event_id;
	}
	/**
	 * @return the event_name
	 */
	public String getEvent_name() {
		return event_name;
	}
	/**
	 * @param event_name the event_name to set
	 */
	public void setEvent_name(String event_name) {
		this.event_name = event_name;
	}
	/**
	 * @return the start_date
	 */
	public String getStart_date() {
		return start_date;
	}
	/**
	 * @param start_date the start_date to set
	 */
	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}
	/**
	 * @return the end_date
	 */
	public String getEnd_date() {
		return end_date;
	}
	/**
	 * @param end_date the end_date to set
	 */
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	/**
	 * @return the venue
	 */
	public String getVenue() {
		return venue;
	}
	/**
	 * @param venue the venue to set
	 */
	public void setVenue(String venue) {
		this.venue = venue;
	}
	/**
	 * @return the time
	 */
	public String getTime() {
		return time;
	}
	/**
	 * @param time the time to set
	 */
	public void setTime(String time) {
		this.time = time;
	}
	/**
	 * @return the expected_amount
	 */
	public String getExpected_amount() {
		return expected_amount;
	}
	/**
	 * @param expected_amount the expected_amount to set
	 */
	public void setExpected_amount(String expected_amount) {
		this.expected_amount = expected_amount;
	}
	/**
	 * @return the total_amount
	 */
	public String getTotal_amount() {
		return total_amount;
	}
	/**
	 * @param total_amount the total_amount to set
	 */
	public void setTotal_amount(String total_amount) {
		this.total_amount = total_amount;
	}
	/**
	 * @return the event_status
	 */
	public String getEvent_status() {
		return event_status;
	}
	/**
	 * @param event_status the event_status to set
	 */
	public void setEvent_status(String event_status) {
		this.event_status = event_status;
	}
	
}
