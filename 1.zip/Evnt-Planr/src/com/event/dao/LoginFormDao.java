package com.event.dao;

import java.sql.*;
import com.event.bean.Login_FormBean;
import com.event.web.jdbc.ConnectionClass;

public class LoginFormDao {
	Connection con=null;
	Statement stmt= null;
	ResultSet rs1 = null;
	ResultSet rs2 = null;
	ResultSet rs = null;
	String sql = null;
	
	public String CheckCredentials(Login_FormBean objLogin_FormBean) throws SQLException {
		con=ConnectionClass.getConnection();
			stmt=con.createStatement();
			
		String sql1="select * from employee where employee_id='"+objLogin_FormBean.getUsername()+"' & password='"+objLogin_FormBean.getPassword()+"' & status=='admin'";
		String sql2="select * from employee where employee_id='"+objLogin_FormBean.getUsername()+"' & password='"+objLogin_FormBean.getPassword()+"' & status!='admin'";

			rs1=stmt.executeQuery(sql1);
			rs2=stmt.executeQuery(sql2);
			if(rs1!=null){
				sql="admin";
			}
			if(rs2!=null){
				sql="employee";
			}
			return sql;
	}

	
}
