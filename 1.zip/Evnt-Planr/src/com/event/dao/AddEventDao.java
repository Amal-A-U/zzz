package com.event.dao;

import java.sql.*;

import com.event.bean.AddEventBean;
import com.event.web.jdbc.ConnectionClass;


public class AddEventDao {
	public String s=null;
	Connection con=null;
	Statement stmt= null;
	ResultSet rs = null;
public String insertEmpDetails(AddEventBean objAddEventBean) {
		
		con=ConnectionClass.getConnection();
		try {
			stmt=con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String sql="insert into AMAL_EVENT (EVENT_ID,EVENT_NAME,START_DATE,END_DATE,VENUE,TIME,EXPECTED_AMOUNT,TOTAL_AMOUNT,EVENT_STATUS) values('"+objAddEventBean.getEvent_id()+"','"+objAddEventBean.getEvent_name()+"','"+objAddEventBean.getStart_date()+"','"+objAddEventBean.getEnd_date()+"','"+objAddEventBean.getVenue()+"','"+objAddEventBean.getTime()+"','"+objAddEventBean.getExpected_amount()+"',,'good')";
		try {
			rs=stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}

}
